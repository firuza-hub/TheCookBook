package com.example.thecookbook.recipesList

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.thecookbook.data.RecipeDataItem

class RecipesListViewModel: ViewModel() {
    val recipes = MutableLiveData<RecipeDataItem>()
}