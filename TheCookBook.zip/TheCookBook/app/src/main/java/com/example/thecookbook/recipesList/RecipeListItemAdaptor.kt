package com.example.thecookbook.recipesList

import com.example.thecookbook.R
import com.example.thecookbook.data.RecipeDataItem
import com.udacity.project4.base.BaseRecyclerViewAdapter

class RecipeListItemAdaptor (callBack: (selectedReminder: RecipeDataItem) -> Unit) :
BaseRecyclerViewAdapter<RecipeDataItem>(callBack) {
    override fun getLayoutRes(viewType: Int) = R.layout.fragment_recipes_item
}