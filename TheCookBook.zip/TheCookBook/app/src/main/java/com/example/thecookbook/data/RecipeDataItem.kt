package com.example.thecookbook.data

data class RecipeDataItem(val id: Int, val title: String)